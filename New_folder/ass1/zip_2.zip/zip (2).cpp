#include <bits/stdc++.h>
//#include<iostream>
#include<string>
using namespace std;
  
int main()
{
    char init[] = "thisisinit";
    char  add[] = "addednow";
   // cout<< init<<endl;
    //strcpy(init ,add);
    char p[20];
    string str = strcpy(p,add);
    string app = init;
    cout<<app<<endl;
    char v[20] = "init";
    cout<<v<<endl;
    //string and = strcpy(init ,add);
    cout<<str<<endl;
    cout<<str.length();
    cout<<strcpy(p,add)<<endl;
    cout<<strlen(p)<<endl;
    for (auto it= str.begin(); it!=str.end();it++)
    {
        cout<<*it;
    }
    return 0;
}
