int Solution::solve(vector<int> &A, int B) {
    int n = (int)A.size(), i = 0, ans = 0;
    if(B == 0)
        return -1;
    //Start from 0th index
    while(i<n)
    {
        int idx = -1;
        //check range [X-B+1, X+B-1] and find rightmost bulb
        for(int j=max(0, i-B+1);j<min(n,i+B);j++)
        {
            if(A[j] == 1)
                idx = j;
        }
        if(idx == -1)
            return -1;
        ans++;
        //Start now from index which is outside the current selected bulb
        i = idx+B;
    }
    return ans;
}


-------------------------------------------------------------------
int Solution::solve(vector<int> &A, int B) {
    int m= A.size();
//    vector<int> B(m,0);
    int count=0;
    for (int i=1;i<A.size();i++)
        {
            vector<int> C(m,0);
            C[0]=1;
            if(A[i]==1)
            {
                count++;
              int x1=i-B+1;
              int x2=i+B-1;  
              
              for (int x=x1;x<=x2;x++)
              {
                  C[x]=1;
              }
            }

              for (int x=0;x<m;x++)
              {
                if (C[x]==0)
                    return -1;}
            return count;
        }
            

        
}





