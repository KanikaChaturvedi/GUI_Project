#include <stdio.h>
#include "myheader.h"

int main( int argc, char const *argv[])
{
    int a=10, b=20;
    int r= add(a,b);
    printf("result: %d\n", r);
    printf("HEY, THIS IS ASSIGNMENT 1 !\n");
    printf("HEY, THIS IS ASSIGNMENT 1 !\n");
    printf("HEY, THIS IS ASSIGNMENT 1 !\n");
    printf("Imported zip in current directory !\n");
    printf("Added menu buttons !\n");
    printf("result: %d\n", r);
    printf("HEY, THIS IS ASSIGNMENT 1 !\n");
    printf("HEY, THIS IS ASSIGNMENT 1 !\n");
    printf("HEY, THIS IS ASSIGNMENT 1 !\n");
    printf("Imported zip in current directory !\n");
    printf("Added menu buttons !\n");
  printf("making changes from container terminal itself!!\n");
  printf("result: %d\n", r);
    printf("HEY, THIS IS ASSIGNMENT 1 !\n");
    printf("HEY, THIS IS ASSIGNMENT 1 !\n");
    printf("HEY, THIS IS ASSIGNMENT 1 !\n");
    printf("Imported zip in current directory !\n");
    printf("Added menu buttons !\n");
    printf("result: %d\n", r);
    printf("HEY, THIS IS ASSIGNMENT 1 !\n");
    printf("HEY, THIS IS ASSIGNMENT 1 !\n");
    printf("HEY, THIS IS ASSIGNMENT 1 !\n");
    printf("Imported zip in current directory !\n");
    printf("Added menu buttons !\n");
  printf("making changes from container terminal itself!!jkgduihgudhguiji\n");
  printf("i have combined upload changes and compile together !!!");

    return 0;
}