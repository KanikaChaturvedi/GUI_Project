// Simple C program to display "Hello World"
 
// Header file for input output functions
#include <stdio.h>
 
// main function -
// where the execution of program begins
int main()
{
    printf("HEY, THIS IS ASSIGNMENT 1 !\n");
    printf("Hello World, I am Amrit ! How are you guys ?\n");
    printf("I am making some changes here!\n");
    printf("Not executing any volume mounting here !\n");
    return 0;
}