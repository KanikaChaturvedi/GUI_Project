#include "myheader.h"

int add(int first, int second)
{
    return first+second;
}