#ifndef MY_HEADER
#define MY_HEADER

int add(int , int );

#endif